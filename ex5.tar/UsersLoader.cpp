#include "UsersLoader.h"
#include <fstream>
#include <sstream>

std::vector<User> UsersLoader::create_users(
    const std::string& users_file_path,
    std::shared_ptr<RecommendationSystem> rs)
{
    std::ifstream file(users_file_path);
    if (!file.is_open()) {
        // no throw => empty
        return {};
    }

    std::vector<User> users;
    std::string line;

    // first line is header "User <movie1> <movie2> ..."
    if (!std::getline(file, line)) {
        return users;
    }
    std::istringstream header(line);
    std::string skip;
    header >> skip; // probably "User"

    std::vector<sp_movie> movies;
    std::string movie_info;

    // read each "Name-Year" from header
    while (header >> movie_info) {
        size_t dash = movie_info.find_last_of('-');
        if (dash == std::string::npos) {
            continue;
        }
        std::string name = movie_info.substr(0, dash);
        int year = 0;
        try {
            year = std::stoi(movie_info.substr(dash+1));
        } catch(...) {
            continue;
        }
        sp_movie mv = rs->get_movie(name, year);
        if (mv) {
            movies.push_back(mv);
        }
    }

    // now read each user line
    while (std::getline(file, line)) {
        if (line.empty()) { continue; }
        std::istringstream iss(line);
        std::string username;
        iss >> username;
        if (username.empty()) {
            continue;
        }
        rank_map ranks(0, sp_movie_hash, sp_movie_equal);

        size_t idx = 0;
        while (idx < movies.size() && !iss.eof()) {
            std::string rating_str;
            iss >> rating_str;
            if (rating_str == "NA") {
                idx++;
                continue;
            }
            if (!iss.fail() && !rating_str.empty()) {
                try {
                    double val = std::stod(rating_str);
                    // skip out-of-range if needed
                    ranks[movies[idx]] = val;
                } catch(...) {
                    // skip invalid
                }
            }
            idx++;
        }
        // add user if they rated at least 1 movie
        if (!ranks.empty()) {
            users.emplace_back(username, ranks, rs);
        }
    }
    return users;
}
